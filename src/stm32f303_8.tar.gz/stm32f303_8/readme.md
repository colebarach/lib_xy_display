# STM32F303 Source

**DISCLAIMER**
This is a work-in-progress implementation of the XY library on the STM32 microcontroller. Note that this version is not compliant with the library as described in the repository readme, this code is made available for educational purposes. For a proper implementation of the library see the pico_8 directory
